Created: 03/21
# Cattle-disease-prediction-using-Machine-Learning
Cattle disease prediction using Machine Learning. This project is used to predict the disease based on the symptoms. It predicts using 4 different machine learning algorithms. So, the output is accurate..
Github:https://github.com/thyagarajank/Cattle-disease-prediction-using-Machine-Learning
